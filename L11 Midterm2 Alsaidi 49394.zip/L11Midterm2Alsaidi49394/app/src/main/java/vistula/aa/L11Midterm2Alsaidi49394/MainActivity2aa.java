package vistula.aa.L11Midterm2Alsaidi49394;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity2aa extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity2aa);




    }
}