package vistula.aa.L11Midterm2Alsaidi49394;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Random;

public class MainActivityAA extends AppCompatActivity {
    TextView textView4aa;
    TextView textView5aa;
    Button buttonaa;
    int id1=4;
    int id2=9;
    int IDnew = 49394;
    Button button2aa;
    EditText editTextNumberaa;
    Button button3aa;
    Button button4aa;
    private static final String TAG = MainActivityAA.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_a);

        textView4aa =findViewById(R.id.textView4aa);
        textView5aa=findViewById(R.id.textView5aa);
        buttonaa=findViewById(R.id.buttonaa);
        button2aa=findViewById(R.id.button2aa);
        editTextNumberaa=findViewById(R.id.editTextNumberaa);
        button3aa=findViewById(R.id.button3aa);
        button4aa=findViewById(R.id.button4aa);


        buttonaa.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                int random_double1 = (int) (Math.random() * (id1 - 1 + 1) + 1);
                int random_double2 = (int) (Math.random() * (id2 - 1 + 1) + 1);
                textView4aa.setText( Integer.toString(random_double1));
                textView5aa.setText(Integer.toString( random_double2));
            }

        });

        button2aa.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                int value = Integer.parseInt(editTextNumberaa.getText().toString().trim());
                int r1=Integer.parseInt(textView4aa.getText().toString().trim());
                int r2=Integer.parseInt(textView5aa.getText().toString().trim());
                int total=r1+r2;
                Log.d(TAG, "onClick: " +total+" ");

                if (r1 + r2 == value){
                    Intent i = new Intent(getApplicationContext(),
                            MainActivity2aa.class);
                    startActivity(i);

                }
                else {

                    Toast.makeText(getApplicationContext(), "Eroor"  , Toast.LENGTH_LONG).show();

                }




            }

        });


        button3aa.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                int value = Integer.parseInt(editTextNumberaa.getText().toString().trim());
                int r1=Integer.parseInt(textView4aa.getText().toString().trim());
                int r2=Integer.parseInt(textView5aa.getText().toString().trim());
                int total=r1+r2;
                Log.d(TAG, "onClick: " +total+" ");

                if (r1 + r2 == value){
                    Intent i = new Intent(getApplicationContext(),
                            MainActivity3aa.class);
                    startActivity(i);

                }
                else {

                    Toast.makeText(getApplicationContext(), "Eroor"  , Toast.LENGTH_LONG).show();

                }




            }

        });

        button4aa.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                int value = Integer.parseInt(editTextNumberaa.getText().toString().trim());
                int r1=Integer.parseInt(textView4aa.getText().toString().trim());
                int r2=Integer.parseInt(textView5aa.getText().toString().trim());
                int total=r1+r2;
                Log.d(TAG, "onClick: " +total+" ");

                if (r1 + r2 == value){
                    Intent i = new Intent(getApplicationContext(),
                            MainActivity4aa.class);
                    startActivity(i);

                }
                else {

                    Toast.makeText(getApplicationContext(), "Eroor"  , Toast.LENGTH_LONG).show();

                }




            }

        });







    }


}